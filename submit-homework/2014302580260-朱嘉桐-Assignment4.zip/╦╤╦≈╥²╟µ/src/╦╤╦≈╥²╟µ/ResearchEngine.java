package ��������;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

public class ResearchEngine{
	private static JFrame f;
	private static JTextArea jta;
	private static JTextField jf;
	private static JButton bt1;
	static int length=200;
    static	String[]info = new String[length];//����Ϣ��������
    static	int i=0;
public static int matcher(String a,String b)//ƥ��
	{
	int n=0;//Ƶ��
	Pattern p=Pattern.compile(a); 
	Matcher m=p.matcher(b); 
	while(m.find()) { 
	     n++; 
	}
	return n;
	}
public static void caltf(int tf[],String a[])//����TFֵ
	{
	for( int j=1;j<tf.length;j ++ )
	{
    for(int i=0;i<tf.length - 1;i ++)
	{
	if( tf[i]<tf[i+1])
	{
	int temp = tf[i];
	tf[i] = tf[i+1];
	tf[i+1] = temp; 
	String temp1=a[i];
	a[i]=a[i+1];
    a[i+1]=temp1;
	}
	}      
	}
}
public static String search(String abc)throws SQLException{//�������ݿ⣬������Ϣ
    int Length = 200;
    int x[]=new int[Length];//�洢Ƶ��
    int middle = 0;//�ؼ���ƥ���
    String Result="�������:";
	Connection conn=null;
	String sql = "select*from professor_info";
	String url="jdbc:mysql://localhost:3306/pi?"
    +"user=root&password=zhujiatong&useUnicode=true&characterEncoding=UTF8";	    
	try
    {
	Class.forName("com.mysql.jdbc.Driver");
	System.out.println("�ɹ�����MySQL��������");
    conn=DriverManager.getConnection(url);
    Statement stmt=conn.createStatement();
    ResultSet rs = stmt.executeQuery(sql);
    while(rs.next())
    {               
    	info[i]=rs.getString(1)+"\n"+rs.getString(2)+"\n"+rs.getString(3)+"\n"+rs.getString(4)+"\n"+rs.getString(5);
    	i++;
    }
    for(int n=0;n<i;n++)
    {
 	  x[n]=matcher(abc,info[n]);
 	  middle=middle+x[n];
    }
    if(middle==0)
    {
 	   System.out.println("ϵͳ�޷�ƥ��ؼ��ʣ�����������");
    }
    caltf(x,info);
 	for(int n=0;n<i;n++)
 	{
 	 Result=Result+"\n"+info[n];
 	}       	   	
    }
	catch (SQLException e) 
	{
	System.out.println("MySQL��������");
    e.printStackTrace();
    } 
	catch (Exception e) 
	{
    e.printStackTrace();
    } 
	finally {
    conn.close();
	}
	return Result;
    }
public static void main(String[] args){//������
		f=new JFrame("GUI");
		f.setBounds(500, 500, 1000, 1000);
		f.setVisible(true);
		f.setLayout(null);
		f.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);	
		jf=new JTextField();
		jf.setBounds(800,200,1400,50);
		jf.setBackground(Color.pink);
		Font mf=new Font("Serif",0,20);
		jf.setFont(mf);
		f.add(jf);
		jta=new JTextArea();
		jta.setBounds(800,300,1600,1000);
		jta.setFont(mf);
		f.add(jta);
		bt1=new JButton("Search");
		bt1.setBounds(2300,200,200,50);
		f.add(bt1);
		bt1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		try {
			jta.setText(search(jf.getText()));
			i=0;
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
		});
	}
	}

	


	